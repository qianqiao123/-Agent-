from fastapi import FastAPI
from app.main import run_pipeline

app = FastAPI()

@app.get("/")
def root():
    return {"msg": "Multi-Agent Data System Running"}

@app.post("/analyze")
def analyze(query: str, file_path: str):
    result = run_pipeline(query, file_path)
    return {"result": result}
